INSERT INTO tb_users (email, senha) VALUES ('laura@gmail.com', '$2a$12$Vy3ClU6lgMV5Vr8REZMyMuU7ll.RrJv2qoMGomSRKcpLT7dxVw912'), ('iolanda@gmail.com', '$2a$12$KfdBTgCIf3T8Zpo/TuQKpuN/1xSQHWo3Nhtve1ktUCBAvQ9KIU2Oe') ;

INSERT INTO tb_roles (authority) VALUES ('ROLE_ADMIN'), ('ROLE_CLIENT');

